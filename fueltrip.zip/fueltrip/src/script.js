/*-- MODAL SYSTEM --*/
const overlay = document.getElementById("overlay")

document.querySelectorAll(".sidebar button").forEach(btn=>{
  btn.addEventListener("click", ()=>{
    const id = btn.dataset.open
    const modal = document.getElementById(id)

    if(!modal) return

    if(modal.classList.contains("show")){
      closeModal()
    }else{
      openModal(modal)
    }
  })
})

function openModal(modal){
  document.querySelectorAll(".modal").forEach(m=>{
    m.classList.remove("show")
  })

  overlay.classList.add("show")
  modal.classList.add("show")
}

function closeModal(){
  overlay.classList.remove("show")
  document.querySelectorAll(".modal").forEach(m=>{
    m.classList.remove("show")
  })
}

overlay.onclick = closeModal

/*-- SIDEBAR COLLAPSE --*/
const sideBtn = document.getElementById("sidebarToggle");

if(localStorage.getItem("sidebar") === "closed"){
  document.body.classList.add("sidebar-collapsed");
}

sideBtn.onclick = ()=>{
  document.body.classList.toggle("sidebar-collapsed");

  localStorage.setItem(
    "sidebar",
    document.body.classList.contains("sidebar-collapsed") ? "closed":"open"
  );
};

/*-- MINI WINDOW --*/
const miniZone=document.getElementById("miniZone");
function mini(id,text){
  let d=document.getElementById(id);
  if(!d){
    d=document.createElement("div");
    d.id=id;
    d.className="mini";
    miniZone.appendChild(d);
  }
  d.textContent=text;
}

/*-- UTIL --*/
function fmt(s){
  const m=Math.floor(s/60).toString().padStart(2,"0");
  const ss=(s%60).toString().padStart(2,"0");
  return m+":"+ss;
}

/*-- TIMER --*/
let tInt=null,tRemain=0,tRunning=false;

tStart.onclick=()=>{
  if(!tRunning){
    if(tRemain===0){
      tRemain=(+tMin.value||0)*60+(+tSec.value||0);
    }
    tRunning=true;
    tStop.textContent="Stop";
    tInt=setInterval(()=>{
      if(tRemain<=0){
        clearInterval(tInt);
        alert("Timer finished");
        return;
      }
      tRemain--;
      timerDisplay.textContent=fmt(tRemain);
      mini("miniTimer","Timer "+fmt(tRemain));
    },1000);
  }
};

tStop.onclick=()=>{
  if(tRunning){
    clearInterval(tInt);
    tRunning=false;
    tStop.textContent="Resume";
  }else{
    tStart.onclick();
  }
};

tReset.onclick=()=>{
  if(confirm("Reset timer?")){
    clearInterval(tInt);
    tRemain=0;
    tRunning=false;
    timerDisplay.textContent="00:00";
    document.getElementById("miniTimer")?.remove();
  }
};

/*-- POMODORO --*/
const pomSeq=[
 ["Focus",25],["Break",5],
 ["Focus",25],["Break",5],
 ["Focus",25],["Break",5],
 ["Focus",25],["Long Break",15]
];
let pIdx=0,pRemain=0,pRun=false,pInt=null;

pomoStart.onclick=()=>{
  if(!pRun){
    if(pRemain===0){
      pIdx=0;
      pRemain=pomSeq[0][1]*60;
    }
    pRun=true;
    pomoStop.textContent="Stop";
    pomoLabel.textContent=pomSeq[pIdx][0];
    pInt=setInterval(()=>{
      if(pRemain<=0){
        pIdx++;
        if(pIdx>=pomSeq.length){
          clearInterval(pInt);
          return;
        }
        pRemain=pomSeq[pIdx][1]*60;
        pomoLabel.textContent=pomSeq[pIdx][0];
      }
      pRemain--;
      pomoDisplay.textContent=fmt(pRemain);
      mini("miniPomo","Pomodoro "+pomoLabel.textContent+" "+fmt(pRemain));
    },1000);
  }
};

pomoStop.onclick=()=>{
  if(pRun){
    clearInterval(pInt);
    pRun=false;
    pomoStop.textContent="Resume";
  }else{
    pomoStart.onclick();
  }
};

pomoReset.onclick=()=>{
  if(confirm("Reset pomodoro?")){
    clearInterval(pInt);
    pIdx=0;
    pRemain=0;
    pRun=false;
    pomoDisplay.textContent="00:00";
    pomoLabel.textContent="";
    document.getElementById("miniPomo")?.remove();
  }
};

/*-- STOPWATCH --*/
let sw=0,swRun=false,swInt=null;

swStart.onclick=()=>{
  if(!swRun){
    swRun=true;
    swStop.textContent="Stop";
    swInt=setInterval(()=>{
      sw++;
      swDisplay.textContent=fmt(sw);
      mini("miniSW","Stopwatch "+fmt(sw));
    },1000);
  }
};

swStop.onclick=()=>{
  if(swRun){
    clearInterval(swInt);
    swRun=false;
    swStop.textContent="Resume";
  }else{
    swStart.onclick();
  }
};

swReset.onclick=()=>{
  if(confirm("Reset stopwatch?")){
    clearInterval(swInt);
    sw=0;
    swRun=false;
    swDisplay.textContent="00:00";
    document.getElementById("miniSW")?.remove();
  }
};

/*-- ALARM SYSTEM --*/

const aName = document.getElementById("aName")
const aDate = document.getElementById("aDate")
const aTime = document.getElementById("aTime")
const aAdd  = document.getElementById("aAdd")
const aList = document.getElementById("aList")

let alarms = JSON.parse(localStorage.getItem("alarms") || "[]")

renderAlarms()

aAdd.onclick = () => {
  if(!aName.value || !aDate.value || !aTime.value) return

  const datetime = new Date(`${aDate.value}T${aTime.value}`).getTime()

  alarms.push({
    title: aName.value,
    time: datetime,
    triggered: false
  })

  aName.value = ""
  aDate.value = ""
  aTime.value = ""

  saveAlarms()
  renderAlarms()
}

function renderAlarms(){
  aList.innerHTML = ""

  alarms.forEach((a, i) => {
    const li = document.createElement("li")

    const t = new Date(a.time)
    const label = `${t.toLocaleDateString()} ${t.toLocaleTimeString([],{
      hour:"2-digit", minute:"2-digit"
    })}`

    li.innerHTML = `
      <div>
        <strong>${a.title}</strong><br>
        <small>${label}</small>
      </div>
      <button>✖</button>
    `

    li.style.display = "flex"
    li.style.justifyContent = "space-between"
    li.style.alignItems = "center"
    li.style.marginBottom = "6px"

    li.querySelector("button").onclick = () => {
      if(confirm("Delete alarm?")){
        alarms.splice(i,1)
        saveAlarms()
        renderAlarms()
      }
    }

    aList.appendChild(li)
  })
}

function saveAlarms(){
  localStorage.setItem("alarms", JSON.stringify(alarms))
}
/*-- ALARM CHECK LOOP --*/

setInterval(() => {
  const now = Date.now()

  alarms.forEach(a => {
    if(!a.triggered && now >= a.time){
      a.triggered = true
      saveAlarms()

      const sound = new Audio("alarm.mp3")
      sound.play().catch(()=>{})

      alert(`⏰ Alarm\n${a.title}`)
    }
  })
}, 1000)

/* -- CHECKLIST -- */
const cInput = document.getElementById("cInput")
const cAdd   = document.getElementById("cAdd")
const cList  = document.getElementById("cList")

let checklist = JSON.parse(localStorage.getItem("checklist") || "[]")
renderChecklist()

cAdd.onclick = () => {
  const text = cInput.value.trim()
  if (!text) return

  checklist.push({
    text,
    done: false
  })

  cInput.value = ""
  saveChecklist()
  renderChecklist()
}

function renderChecklist(){
  cList.innerHTML = ""

  checklist.forEach((item, index) => {
    const li = document.createElement("li")

    li.innerHTML = `
      <label style="display:flex;align-items:center;gap:8px;">
        <input type="checkbox" ${item.done ? "checked" : ""}>
        <span style="${item.done ? "text-decoration:line-through;opacity:.6" : ""}">
          ${item.text}
        </span>
      </label>
      <button style="margin-left:auto;">✖</button>
    `

    li.querySelector("input").onchange = (e) => {
      checklist[index].done = e.target.checked
      saveChecklist()
      renderChecklist()
    }

    li.querySelector("button").onclick = () => {
      if(confirm("Delete task?")){
        checklist.splice(index, 1)
        saveChecklist()
        renderChecklist()
      }
    }

    li.style.display = "flex"
    li.style.alignItems = "center"
    li.style.gap = "8px"

    cList.appendChild(li)
  })
}

function saveChecklist(){
  localStorage.setItem("checklist", JSON.stringify(checklist))
}

/*-- SCHEDULE --*/
sAdd.onclick=()=>{
  if(!sDay.value||!sTime.value||!sTitle.value)return;
  const li=document.createElement("li");
  li.innerHTML=`• ${sDay.value} ${sTime.value} - ${sTitle.value} <button>✖</button>`;
  li.querySelector("button").onclick=()=>{
    if(confirm("Delete item?"))li.remove();
  };
  sList.appendChild(li);
  sDay.value=sTime.value=sTitle.value="";
};

/*-- FLASHCARD --*/
let fcData = JSON.parse(localStorage.getItem("fcData")||"[]")
let currentCat=null, previewIndex=0, previewSide=0

const $=id=>document.getElementById(id)

function saveFC(){
  localStorage.setItem("fcData",JSON.stringify(fcData))
}

function showFC(el){
  fcCategories.classList.add("hidden")
  fcPreview.classList.add("hidden")
  fcEditor.classList.add("hidden")
  el.classList.remove("hidden")
}

/*-- CATEGORY --*/
function renderCategories(){
  fcCatList.innerHTML=""
  fcData.forEach((c,i)=>{
    const w=document.createElement("div")
    const b=document.createElement("button")
    b.textContent=c.name
    b.onclick=()=>openPreview(i)

    const d=document.createElement("button")
    d.textContent="✖"
    d.onclick=e=>{
      e.stopPropagation()
      if(confirm("Delete category?")){
        fcData.splice(i,1)
        saveFC(); renderCategories()
      }
    }
    w.append(b,d)
    fcCatList.appendChild(w)
  })
}
renderCategories()

fcNewCat.onclick=()=>{
  currentCat={name:"",cards:[]}
  fcCatName.value=""
  fcCards.innerHTML=""
  addCardInput()
  showFC(fcEditor)
}

/*-- PREVIEW --*/
function openPreview(i){
  currentCat=fcData[i]
  previewIndex=0; previewSide=0
  renderPreview()
  showFC(fcPreview)
}

function renderPreview(){
  if(!currentCat.cards.length)return
  fcPreviewCard.classList.toggle("flipped",previewSide)
  fcPreviewCard.querySelector(".fc-front").textContent=currentCat.cards[previewIndex][0]
  fcPreviewCard.querySelector(".fc-back").textContent=currentCat.cards[previewIndex][1]
}

fcPreviewCard.onclick=e=>{
  e.stopPropagation()
  previewSide^=1
  renderPreview()
}

fcNext.onclick=()=>{
  previewIndex=(previewIndex+1)%currentCat.cards.length
  previewSide=0
  renderPreview()
}

fcShuffle.onclick=()=>{
  currentCat.cards.sort(()=>Math.random()-.5)
  saveFC()
  previewIndex=0
  renderPreview()
}

/*-- EDITOR --*/
fcEdit.onclick=()=>{
  fcCatName.value=currentCat.name
  fcCards.innerHTML=""
  currentCat.cards.forEach(c=>addCardInput(c[0],c[1]))
  showFC(fcEditor)
}

function addCardInput(f="",b=""){
  const r=document.createElement("div")
  r.className="fcCardRow"
  r.innerHTML=`
    <input placeholder="Front" value="${f}">
    <input placeholder="Back" value="${b}">
    <button>✖</button>`
  r.querySelector("button").onclick=()=>{
  if(confirm("Delete?")){
    r.remove()
    }
  }
  fcCards.appendChild(r)
}

fcAddCard.onclick=()=>addCardInput()

fcSave.onclick=()=>{
  currentCat.name=fcCatName.value||"Untitled"
  currentCat.cards=[...fcCards.children]
    .map(r=>[r.children[0].value,r.children[1].value])
    .filter(c=>c[0]||c[1])

  if(!fcData.includes(currentCat))fcData.push(currentCat)
  saveFC(); renderCategories()
  showFC(fcCategories)
}

fcCancel.onclick=fcBack.onclick=()=>showFC(fcCategories)

/*-- CALCULATOR --*/
const calcValues = [
  "7","8","9","/",
  "4","5","6","*",
  "1","2","3","-",
  "0",".","=","+",
  "C","⌫"
]

calcValues.forEach(v=>{
  const b=document.createElement("button")
  b.textContent=v

  b.onclick=()=>{
    if(v==="="){
      try{
        calcDisplay.value = eval(calcDisplay.value)
      }catch{
        calcDisplay.value="Error"
      }
    }
    else if(v==="C"){
      calcDisplay.value=""
    }
    else if(v==="⌫"){
      calcDisplay.value =
        calcDisplay.value.slice(0,-1)
    }
    else{
      calcDisplay.value+=v
    }
  }

  calcBtns.appendChild(b)
})

/*-- NOTEBOOK --*/
note.value=localStorage.note||"";
note.oninput=()=>localStorage.note=note.value;

/*-- BACKGROUND VIDEO SYSTEM --*/
const bgVideo = document.getElementById("bgVideo")
const soundBtn = document.getElementById("soundToggle")
const soundIcon = document.getElementById("soundIcon")

const VIDEO_LINKS = {
  1:{
    clear:{
      day:     "https://res.cloudinary.com/dmptbtnke/video/upload/v1772054475/copy_B0FFB2BC-DB09-4851-B4AB-24504A1A8B08_jgb05b.mov",
      evening: "PUT_LINK_HERE",
      night:   "PUT_LINK_HERE"
    },
    rain:{
      day:     "PUT_LINK_HERE",
      evening: "PUT_LINK_HERE",
      night:   "PUT_LINK_HERE"
    }
  },

  2:{
    clear:{
      day:     "PUT_LINK_HERE",
      evening: "PUT_LINK_HERE",
      night:   "PUT_LINK_HERE"
    },
    rain:{
      day:     "PUT_LINK_HERE",
      evening: "PUT_LINK_HERE",
      night:   "PUT_LINK_HERE"
    }
  }
}

let BG = {
  scene: 1,
  weather: "clear",
  time: "day"
}

let soundOn = localStorage.getItem("bgm") === "on"

function updateBackground(){

  const src =
    VIDEO_LINKS?.[BG.scene]
    ?. [BG.weather]
    ?. [BG.time]

  if(!src) return

  bgVideo.src = src
  bgVideo.loop = true
  bgVideo.muted = !soundOn

  bgVideo.play().catch(()=>{})
  highlightButtons()
}

function highlightButtons(){

  document
    .querySelectorAll("#background button")
    .forEach(b=>b.classList.remove("active"))

  document
    .querySelector(`#background [data-scene="${BG.scene}"]`)
    ?.classList.add("active")

  document
    .querySelector(`#background [data-weather="${BG.weather}"]`)
    ?.classList.add("active")

  document
    .querySelector(`#background [data-time="${BG.time}"]`)
    ?.classList.add("active")
}

document.querySelectorAll("#background [data-scene]")
.forEach(btn=>{
  btn.onclick=()=>{
    BG.scene = btn.dataset.scene
    updateBackground()
  }
})

document.querySelectorAll("#background [data-weather]")
.forEach(btn=>{
  btn.onclick=()=>{
    BG.weather = btn.dataset.weather
    updateBackground()
  }
})

document.querySelectorAll("#background [data-time]")
.forEach(btn=>{
  btn.onclick=()=>{
    BG.time = btn.dataset.time
    updateBackground()
  }
})

const ICON_ON  = "https://cdn-icons-png.flaticon.com/512/727/727269.png"
const ICON_OFF = "https://cdn-icons-png.flaticon.com/512/727/727240.png"

function applySound(){
  bgVideo.muted = !soundOn
  soundIcon.style.backgroundImage =
    `url(${soundOn ? ICON_ON : ICON_OFF})`
}

soundBtn.onclick=()=>{
  soundOn=!soundOn
  localStorage.setItem("bgm", soundOn?"on":"off")
  applySound()
}

document.addEventListener("click",()=>{
  bgVideo.play().catch(()=>{})
},{once:true})

applySound()
updateBackground()

if(window.innerWidth < 500){
  document.body.classList.add("sidebar-collapsed")
}